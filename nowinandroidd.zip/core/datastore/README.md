# :core:datastore module
## Dependency graph
![Dependency graph](../../docs/images/graphs/dep_graph_core_datastore.svg)
