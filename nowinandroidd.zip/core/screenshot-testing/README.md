# :core:screenshot-testing module
## Dependency graph
![Dependency graph](../../docs/images/graphs/dep_graph_core_screenshot_testing.svg)
