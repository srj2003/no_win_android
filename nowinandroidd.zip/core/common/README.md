# :core:common module
## Dependency graph
![Dependency graph](../../docs/images/graphs/dep_graph_core_common.svg)
